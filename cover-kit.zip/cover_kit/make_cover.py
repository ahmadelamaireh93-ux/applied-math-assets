#!/usr/bin/env python3
"""Replace slide 1 of a deck with the official ASU Applied Mathematics cover.

Usage:
  python3 make_cover.py deck.pptx out.pptx --lecture 04 --title "Limit of a Function and Limit Laws"

Build the deck with a blank first slide, then run this script.
The cover keeps the Lecture 01 design exactly; only the lecture number and title change.
"""
import argparse, os, re, zipfile
from xml.sax.saxutils import escape

KIT = os.path.dirname(os.path.abspath(__file__))
IMG_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck"); ap.add_argument("out")
    ap.add_argument("--lecture", required=True); ap.add_argument("--title", required=True)
    a = ap.parse_args()
    slide = open(os.path.join(KIT, "cover_slide.xml"), encoding="utf8").read()
    slide = slide.replace("{{LECTURE_NO}}", escape(a.lecture)).replace("{{LECTURE_TITLE}}", escape(a.title))
    zin = zipfile.ZipFile(a.deck)
    names = zin.namelist()
    old = zin.read("ppt/slides/_rels/slide1.xml.rels").decode("utf8")
    keep = [m for m in re.findall(r"<Relationship [^>]*/>", old) if IMG_REL not in m]
    rels = ['<Relationship Id="rId%d" Type="%s" Target="../media/asu_cover_%d.png"/>' % (i, IMG_REL, i) for i in range(1, 7)]
    for k, m in enumerate(keep):  # layout / notes relationships of the original slide 1
        rels.append(re.sub(r'Id="[^"]+"', 'Id="rIdK%d"' % k, m))
    rels_xml = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
                '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + "".join(rels) + "</Relationships>")
    files = {n: zin.read(n) for n in names}
    files["ppt/slides/slide1.xml"] = slide.encode("utf8")
    files["ppt/slides/_rels/slide1.xml.rels"] = rels_xml.encode("utf8")
    for i in range(1, 7):
        files["ppt/media/asu_cover_%d.png" % i] = open(os.path.join(KIT, "media", "cover_%d.png" % i), "rb").read()
    ct = files["[Content_Types].xml"].decode("utf8")
    if 'Extension="png"' not in ct:
        ct = ct.replace("<Default ", '<Default Extension="png" ContentType="image/png"/><Default ', 1)
        files["[Content_Types].xml"] = ct.encode("utf8")
    # drop media no longer referenced by any relationship
    used = set()
    for n, d in files.items():
        if n.endswith(".rels"):
            for t in re.findall(r'Target="([^"]+)"', d.decode("utf8", "ignore")):
                used.add(os.path.basename(t))
    for n in [n for n in files if n.startswith("ppt/media/") and os.path.basename(n) not in used]:
        del files[n]
    order = [n for n in names if n in files] + [n for n in files if n not in names]
    with zipfile.ZipFile(a.out, "w", zipfile.ZIP_DEFLATED) as z:
        for n in order: z.writestr(n, files[n])
    print("cover applied:", a.out)

if __name__ == "__main__":
    main()
