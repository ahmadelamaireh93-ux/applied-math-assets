# ASU Cover Kit — Applied Mathematics (830101)

The official lecture cover taken from Lecture 01 (logo, title, graphs, lecturer card, faculty block, watermark).

| File | Purpose |
|---|---|
| `cover_slide.xml` | Slide XML of the cover, with `{{LECTURE_NO}}` and `{{LECTURE_TITLE}}` placeholders |
| `media/cover_1.png … cover_6.png` | Background, ASU logo, f(x) badge, three graphs |
| `make_cover.py` | Replaces slide 1 of any deck with this cover |

## Use
1. Build the deck with a blank first slide (13.333 × 7.5 in).
2. Run:
   `python3 make_cover.py deck.pptx out.pptx --lecture 05 --title "Lecture title"`
3. Validate and render as usual.
